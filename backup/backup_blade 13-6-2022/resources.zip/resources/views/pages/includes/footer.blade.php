<footer class="main-footer" style="font-size: 14px">
    <div class="float-right d-none d-sm-block">
        <b>@lang('site.verion')</b> 1.0.0
    </div>
    <strong> &copy; @php echo date('Y') @endphp @lang('site.copy_right')</strong>
</footer>
